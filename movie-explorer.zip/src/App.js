import { useState } from 'react';
import MovieCard from './components/MovieCard';
import MovieDetails from './components/MovieDetails';
import './App.css';

const API_KEY = 'YOUR_OMDB_API_KEY';

function App() {
  const [query, setQuery] = useState('');
  const [movies, setMovies] = useState([]);
  const [selectedMovie, setSelectedMovie] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const searchMovies = async () => {
    setLoading(true);
    setError('');
    setSelectedMovie(null);
    try {
      const res = await fetch(`https://www.omdbapi.com/?apikey=${API_KEY}&s=${query}`);
      const data = await res.json();
      if (data.Response === 'True') {
        setMovies(data.Search);
      } else {
        setError(data.Error);
      }
    } catch (err) {
      setError('Failed to fetch data');
    }
    setLoading(false);
  };

  const fetchDetails = async (id) => {
    setLoading(true);
    try {
      const res = await fetch(`https://www.omdbapi.com/?apikey=${API_KEY}&i=${id}&plot=full`);
      const data = await res.json();
      if (data.Response === 'True') {
        setSelectedMovie(data);
      } else {
        setError(data.Error);
      }
    } catch {
      setError('Failed to load movie details');
    }
    setLoading(false);
  };

  return (
    <div className="app-container">
      <h1>Movie Explorer</h1>
      <div className="search-bar">
        <input
          type="text"
          placeholder="Search movies by title..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <button onClick={searchMovies}>Search</button>
      </div>
      {loading && <p>Loading...</p>}
      {error && <p className="error">{error}</p>}
      {!loading && !selectedMovie && (
        <div className="movie-list">
          {movies.map((movie) => (
            <MovieCard key={movie.imdbID} movie={movie} onSelect={fetchDetails} />
          ))}
        </div>
      )}
      {!loading && selectedMovie && <MovieDetails movie={selectedMovie} onBack={() => setSelectedMovie(null)} />}
    </div>
  );
}

export default App;
