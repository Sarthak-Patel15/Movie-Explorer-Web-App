import './MovieDetails.css';

function MovieDetails({ movie, onBack }) {
  return (
    <div className="movie-details">
      <button className="back-button" onClick={onBack}>Back to results</button>
      <div className="details-container">
        <img src={movie.Poster !== 'N/A' ? movie.Poster : '/no-image.png'} alt={movie.Title} />
        <div className="details-text">
          <h2>{movie.Title} ({movie.Year})</h2>
          <p><strong>Genre:</strong> {movie.Genre}</p>
          <p><strong>Director:</strong> {movie.Director}</p>
          <p><strong>Actors:</strong> {movie.Actors}</p>
          <p><strong>Plot:</strong> {movie.Plot}</p>
          <p><strong>IMDb Rating:</strong> {movie.imdbRating}</p>
        </div>
      </div>
    </div>
  );
}

export default MovieDetails;
